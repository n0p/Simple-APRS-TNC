Readme.txt for 3x05Ball.zip.

3x05Ball.zip contains files pertaining to "An Inexpensive Terminal Node Controller for Packet Radio," by Bob Ball, WB8WGA (QEX, Mar/Apr, 2005 
pp 16-25). At the time this was posted, the author's e-mail was wb8wga@arrl.net.

The files you have downloaded are source and hex files for programming the project's PIC microcontroller.

73, Bob, KU7G
3:05 PM Tuesday, March 01, 2005

The "Modemless TNC VI.asm" file was updated on 3/10/05 to credit some earlier work for which credit was inadvertantly omitted from the original. 10:33 AM 03/10/2005

Robert J. Schetgen, KU7G/1				Senior Assistant Technical Editor			
American Radio Relay League, 225 Main St, Newington, CT 06111-1494
ph: 860-594-0277 (direct)					fax: 860-594-0259	
e-mail: rschetgen@arrl.org  

QST Team  *  Hints & Kinks Editor   *  QEX Managing Editor							

Have you seen the new QEX? Wow! Check it out at http://www.arrl.org/qex/.




NOTE FOR TNC USERS. THIS INFO PROVIDED WITH PERMISSION OF SPARK FUN ELECTRONICS. I HAVE ADDED COMMENTS RELATIVE TO TNC USE IN CAPS AND IN PARENTHESIS. WB8WGA
=====================================================================
Bloader and Screamer v1.4 for Microchip PIC boot loading
Spark Fun Electronics (www.sparkfun.com)

6-16-04

The purpose of a boot loader is to load programs onto a microcontroller over a serial line without the need of a high voltage or otherwise hardware orientated programmer. What this means to you is that you will now be able to load programs much faster and much easier onto PICs then you ever dreamed of.

Bloader is the program that resides on the PIC. Screamer is the windows program that parses the HEX program file. The two work in unison to make for very fast downloads. 8K can be downloaded in under 9 seconds.

=======================================================



What's a boot loader?

A boot loader is a little program running on a PIC that takes incoming input and records the incoming data into the program area of the PIC's memory. In other words, we send the PIC a serial signal of 1s and 0s and the PIC records these into the program memory.

The purpose of a boot loader is to load programs onto a microcontroller over a serial line without the need of a high voltage or otherwise hardware orientated programmer. What this means to you is that you will now be able to load programs much faster and much easier onto PICs then you ever dreamed of.

Bloader is the program that resides on the PIC. Screamer is the windows program that parses the HEX program file. The two work in unison to make for very fast downloads. 8K can be downloaded in under 9 seconds.

=======================================================



=======================================================

How to get Bloader and Screamer to work:

1) Download the latest Bloader and Screamer versions from www.sparkfun.com

2) Find the appropriate "Bloader-XXX-###.hex" file where XXX is the chip type and ### is the external oscillator speed. Ex: "Bloader-873A-20MHz.hex". (FOR THE TNC, use the F88 VERSION)

3) You must burn Bloader onto the PIC with a hardware programmer. This is generally done with a PG2C or MCP programmer. (MAKE SURE TO SELECT INHX8M AS THE OUTPUT TYPE AND TURN OFF MASTER CLEAR ENABLE)

4) Put the PIC into your breadboard if you had to remove it for programming. You application must have a serial connection, MCLR pull-up resistor, reset button, and 5V power. We use the RS232 Shifter for all of our development but a MAX232 is always a better way to go. All the Olimex development boards have a MAX232 circuit built in, but you will have to connect the UART on the PIC to the MAX232 chip. (THE TNC AS DESCRIBED, NEEDS NO MODIFICATION. JUST UNPOWER FOR ABOUT 3 SECONDS AND REPOWER THE UNIT INSTEAD OF USING THE RESET SWITCH).

5) Plug in the power and serial connection. Open hyperterminal and verify that the PIC is outputting 'Ok' to the terminal screen at 9600bps 8-N-1. This verifies that Bloader was loaded correctly and that your serial connection is working correctly. Close the hyperterminal window.

6) Now open Screamer. Select the Chip Type, Osc Speed, Comm Port, and Baud Rate (start with 9600). Click 'Open' and find the file "SerialTest-XXX-###.hex" file where XXX matches your chip and ### matches your oscillator speed. Click download - hit the reset button on your board. Screamer should load the new HEX file.

7) Open hyperterminal again. Hit a button on the keyboard. The new program should display "Waiting for input:" and repeat any button you press. Now hit the reset button - the same thing should appear. The PIC can be reset and if Screamer is not active, the PIC will automatically run the currently loaded program.

=======================================================

Things you should know:

Once you've loaded Bloader onto your PIC, it will run it's default program and transmit 'Ok' at 9600bps as well as blink all pins on all ports at roughly 1Hz. This way you can tell if your PIC is powered correctly and is running, and if you've got the serial interface wired correctly.

You must have all programs start at memory location 0x0004. This allows a boot vector to sit in spots 0x00-0x02 and the jumper vector to sit at 0x03. Interrupt vectors are still allowed and operate without problems from 0x0004. Read Code Bumping for more information about inserting the necessary commands into your compiler. (THIS IS TAKEN CARE OF IN THE TNC SOFTWARE)

There is always a very small chance that Bloader will bit the dust in the event of some unknown and unforeseeable error. Keep your hardware programmer around in case you need to re-load Bloader. (THIS IS NOT A PROBLEM IF YOU JUST UNPOWER FOR 3 SECONDS OR SO AND REPOWER. THE POWER SUPPLY FILTERING PREVENTS ANY PROBLEMS).

Bloader will turn off the UART (CREN = 0 and TXEN = 0) upon exiting the boot loader program. If you program uses the UART, you will need to re-initialize the UART with your own settings. (DONE IN TNC SOFTWARE)

Bloader can only update the program space. There is no way to change the configuration word without an external hardware programmer. The Oscillator setting, the Watch Dog Timer, and code protection bits are all set when Bloader is installed onto a PIC and cannot be changed during a boot load. They must be changed by re-programming the PIC. Keep this in mind. (TAKEN CARE OF IN THE TNC SOFTWARE)

Debugging abilities of the PIC are turned off. If you're using a debugger like the ICD2, don't even try to use Bloader as well - it'll just get too hairy. Who needs a hardware debugger anyways when you can try a new program within a second or so?

That's it! Have fun! 

=======================================================

All information is free for instructional purposes! If you use any of this information, or find any of it useful - please let us know! We don't limit the use any of our code, but it's always nice to hear when it does get used. If you really like using our boot loader, please consider buying some parts or hardware from our store at www.sparkfun.com. You may not use any part of this information for commercial deployments without permission.
